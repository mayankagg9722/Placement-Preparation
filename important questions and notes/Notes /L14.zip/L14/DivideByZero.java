package L14;

public class DivideByZero extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
