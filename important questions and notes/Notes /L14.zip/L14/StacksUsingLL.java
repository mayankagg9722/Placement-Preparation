package L14;

public class StacksUsingLL<T> {
	Node<T> head;
	int size;
	
	/*public int size() {
		
	}*/
	
	public void push(T data) {
		
	}
	
}
