package L15;

import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		ArrayList<Integer> ar = new ArrayList<Integer>();
		ar.get(0);
	}
}
