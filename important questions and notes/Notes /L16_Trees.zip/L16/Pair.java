package L16;

public class Pair<T> {
	Node<T> head;
	Node<T> tail;
}
