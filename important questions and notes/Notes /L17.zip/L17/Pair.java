package L17;

public class Pair {
	int diameter;
	int height;
}
