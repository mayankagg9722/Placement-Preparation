package L18;

public class Manager {

	public static void main(String[] args) {
		BSTClass t1 = new BSTClass();
		t1.addElement(10);
		
		
		BSTClass t2 = new BSTClass();
		t2.addElement(20);
		
		
		BSTClass t3 = new BSTClass();
		t3.addElement(30);
	}

}
