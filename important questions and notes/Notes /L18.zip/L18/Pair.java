package L18;

public class Pair<T> {
	T Largest;
	T secondLargest;
}
