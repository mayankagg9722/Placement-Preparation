package L22;

import java.util.ArrayList;

public class GraphUse {

	public static void main(String[] args) throws VertexNoFoundException {
		Graph g = new Graph("Road Network");
		/*g.addVertex("A");
		g.addVertex("B");
		g.addVertex("C");
		g.addVertex("D");
		g.addVertex("E");
//		g.printGraph();
		g.addEdge("A", "B");
		g.addEdge("A", "C");
		g.addEdge("A", "E");
		g.addEdge("B", "D");
		g.addEdge("C", "D");
		g.addEdge("E", "D");
		g.addVertex("N");
		System.out.println(g.totalNumEdgesInGraph());
		g.printGraph();
		
		System.out.println(g.hasPath("A", "D"));*/
		
		g.addVertex("A");
		g.addVertex("B");
		g.addVertex("C");
		g.addVertex("D");
		g.addVertex("E");
		g.addVertex("F");
		g.addEdge("A", "C");
		g.addEdge("B", "E");
		g.addEdge("C", "E");
		g.addEdge("F", "E");
		g.printGraph();
		System.out.println(g.hasPath_dfs("A", "F"));
		ArrayList<String> path = g.getPath_dfs("A", "F");
		for(String s : path) {
			System.out.println(s);
		}
		
	}

}
