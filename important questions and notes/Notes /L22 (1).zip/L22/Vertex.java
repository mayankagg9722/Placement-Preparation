package L22;

import java.util.ArrayList;

public class Vertex {
	String name;
	ArrayList<Edge> edgeList;
	
	public Vertex(String name) {
		this.name = name;
		edgeList = new ArrayList<Edge>();
	}

	public ArrayList<Vertex> allAdjacentVertices() {
		ArrayList<Vertex> output = new ArrayList<Vertex>();
		for(Edge e : edgeList) {
			if(e.first.name.equals(this.name)) {
				output.add(e.second);
			}
			else if(e.second.name.equals(this.name)) {
				output.add(e.first);
			}
		}
		return output;
	}

	public void removeEdgeWith(Vertex v) {
		for(Edge e : edgeList) {
			if(e.first.equals(v.name) || e.second.equals(v.name)) {
				edgeList.remove(e);
				return;
			}
		}
	}

	public int numEdgesOfVertex() {
		return edgeList.size();
	}

	public void addEdge(Edge newEdge) {
		edgeList.add(newEdge);
	}

	public boolean isAdjacent(Vertex secondVertex) {
		for(Edge e : edgeList) {
			if(e.first.name.equals(secondVertex.name) || e.second.name.equals(secondVertex.name)) {
				return true;
			}
		}
		return false;
	}
	

	public void printAdjacentVertices() {
		ArrayList<Vertex> adjacent = this.allAdjacentVertices();
		for(Vertex v : adjacent) {
			System.out.print(v.name + ", ");
		}
	}
}
