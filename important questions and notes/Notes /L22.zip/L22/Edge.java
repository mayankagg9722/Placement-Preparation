package L22;

public class Edge {
	Vertex first;
	Vertex second;
//	int distance;
	
	public Edge(Vertex first, Vertex second) {
		this.first = first;
		this.second = second;
	}
	
}
