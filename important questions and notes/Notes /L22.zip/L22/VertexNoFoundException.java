package L22;

public class VertexNoFoundException extends Exception {

}
