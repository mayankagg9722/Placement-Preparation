package L24;

public class bstSubtreeReturn {
	int max;
	int min;
	int size;
	boolean isBST;
}
