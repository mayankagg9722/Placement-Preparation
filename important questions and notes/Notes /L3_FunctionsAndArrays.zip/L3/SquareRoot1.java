package L3;

import java.util.Scanner;

public class SquareRoot1 {

	public static void main(String[] args) {
		
		double d = 4.0 + 0.1 - 0.1;
		System.out.println(d);
		
//		Scanner s = new Scanner(System.in);
//		System.out.println("Enter number : ");
//		int n = s.nextInt();
//		System.out.println("Enter no of decimal places : ");
//		int d = s.nextInt();
//		double output = 0;
//		double increment = 1;
//		int decimalNumber = 0;
//		while(decimalNumber <= d) {
//			while(output*output <= n) {
//				output = output + increment;
//			}
//			output = output - increment;
//			increment = increment * 0.1;
//			decimalNumber = decimalNumber + 1;
//		}
//		System.out.println(output);
	}

}
