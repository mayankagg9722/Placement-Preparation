package L11_OOPS;

public class ProductUse {

	public static void fact(int n) {
//		return 1;
		System.out.println("hi");
	}
	
	public static void main(String[] args) {
	
		Product p = new Product("Laptop", 10, 1009);
		
		System.out.println(p.getName());
		p.setName("nidhi", null);
		
		p.name = "!2";
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		ProductUse o = new ProductUse();
//		fact(10);
		
//		Product p = new Product();
		
//		System.out.println(p.name + " " + p.price + " " + p.numProducts);
//		
////		p.name = "Laptop";
//		p.price = 50000;
//		Product.numProducts = 100;
//		
//		System.out.println(p.name + " " + p.price + " " + p.numProducts);
		
//		Product p2 = new Product();
//		p2.name = "Smartphone";
//		p2.price = 10000;
//		p2.numProducts = 99;
//		
//		System.out.println("Smartphone : " + p2.name + " " + p2.price + " " + p2.numProducts);
//		
//		System.out.println(p.numProducts);
		
//		System.out.println(p.getName());
		
	}

}
