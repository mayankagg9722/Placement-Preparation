package L11_OOPS;

public class Vehicle {
	String name;
	int price;
	
	/*public Vehicle() {
		System.out.println("Vehicle");
	}*/
	
	public Vehicle(int price) {
		this.price = price;
	}
	
}
