package L11_OOPS;

public class VehicleUse {

	public static void main(String[] args) {
		Car c = new Car("ABC", 10);
		
		BMW b = new BMW("DEF", 10);
		
	}

}
