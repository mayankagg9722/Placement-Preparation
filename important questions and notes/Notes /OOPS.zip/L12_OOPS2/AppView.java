package L12_OOPS2;

public interface AppView {
	
	 void display(int a);
}
