package L12_OOPS2;

public interface AppView2 {
	public void display();
}
