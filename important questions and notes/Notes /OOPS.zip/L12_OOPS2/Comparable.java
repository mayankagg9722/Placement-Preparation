package L12_OOPS2;

public interface Comparable<T> {
	public boolean isGreater(T x);
}
