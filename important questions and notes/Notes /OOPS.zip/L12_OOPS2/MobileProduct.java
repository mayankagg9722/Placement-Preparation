package L12_OOPS2;

public class MobileProduct extends Product {
	String companyName;
	
	public void display() {
		/*int a = 10;
		System.out.println("a = " + a);
		System.out.println(companyName);
		System.out.println("Mobile");*/
//		super.display();
	}
	
	public void test() {
		System.out.println("Hey");
	}
	
}
