package L12_OOPS2;

final class ProductUse {

	/*public static void test() {
		
	}
	
	public static int test() {
		return 0;
	}*/
	
	public static void main(String[] args) {
		Product p2 = new MobileProduct();
		
//		p2.price = 100;
//		p2.ID = 100001;
	
//		p2.display();
		
		Product p3 = new Samsung();
		
		
		
	}

}
