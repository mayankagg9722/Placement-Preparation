package L12_OOPS2;

public class Samsung extends MobileProduct{
	int SamsunId;
}
