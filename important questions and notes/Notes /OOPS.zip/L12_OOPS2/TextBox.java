package L12_OOPS2;

public class TextBox implements AppView, AppView2{

	

	public void display(int a) {
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

	/*@Override
	protected void display() {
		System.out.println("Text");
	}*/

}
