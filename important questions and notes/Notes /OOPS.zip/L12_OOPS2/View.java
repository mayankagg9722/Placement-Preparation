package L12_OOPS2;

public abstract class View {

	protected abstract void display();
	
	public  void test() {
		
	}
	
	public void test_2() {
		System.out.println("Hello");
	}
	
}
